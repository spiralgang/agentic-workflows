set -gx --append PATH /data/data/com.termux/files/usr/bin/texlive
set -gx TEXMFROOT /data/data/com.termux/files/usr/share/texlive/2026
set -gx TEXMFLOCAL /data/data/com.termux/files/usr/share/texlive/texmf-local
set -gx OSFONTDIR /data/data/com.termux/files/usr/share/fonts/TTF
set -gx TRFONTS /data/data/com.termux/files/usr/share/groff/current/font/devps /data/data/com.termux/files/usr/share/groff/site-font/devps
