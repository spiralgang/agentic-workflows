#!/data/data/com.termux/files/usr/bin/bash

# Setup TERMUX_APP_PACKAGE_MANAGER
source "/data/data/com.termux/files/usr/bin/termux-setup-package-manager" || exit 1

terminal_width="$(stty size | cut -d" " -f2)"
if [[ "$terminal_width" =~ ^[0-9]+$ ]] && [ "$terminal_width" -gt 60 ]; then

    motd="
 \e[47m                \e[0m  \e[1mWelcome to Termux!\e[0m
 \e[47m  \e[0m            \e[0;37m\e[47m .\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mDocs:\e[0m      \e[4mhttps://termux.dev/docs\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mDonate:\e[0m    \e[4mhttps://termux.dev/donate\e[0m
 \e[47m  \e[0m            \e[47m  \e[0m  \e[1mCommunity:\e[0m \e[4mhttps://termux.dev/community\e[0m
 \e[47m  \e[0m            \e[0;37m\e[47m .\e[0m
 \e[47m                \e[0m  \e[1mTermux version:\e[0m ${TERMUX_VERSION-Unknown}
"

    motd_indent="                   "

else

    motd="
\e[1mWelcome to Termux!\e[0m

\e[1mDocs:\e[0m      \e[4mhttps://termux.dev/docs\e[0m
\e[1mDonate:\e[0m    \e[4mhttps://termux.dev/donate\e[0m
\e[1mCommunity:\e[0m \e[4mhttps://termux.dev/community\e[0m

\e[1mTermux version:\e[0m ${TERMUX_VERSION-Unknown}
"

    motd_indent=""
fi

motd+="
${motd_indent}\e[1mWorking with packages:\e[0m
${motd_indent}\e[1mSearch:\e[0m  pkg search <query>
${motd_indent}\e[1mInstall:\e[0m pkg install <package>
${motd_indent}\e[1mUpgrade:\e[0m pkg upgrade
"


if [ "$TERMUX_APP_PACKAGE_MANAGER" = "apt" ]; then

    motd+="
${motd_indent}\e[
enable .
enable :
enable [
enable alias
enable bg
enable bind
enable break
enable builtin
enable caller
enable cd
enable command
enable compgen
enable complete
enable compopt
enable continue
enable declare
enable dirs
enable disown
enable echo
enable enable
enable eval
enable exec
enable exit
enable export
enable false
enable fc
enable fg
enable getopts
enable hash
enable help
enable history
enable jobs
enable kill
enable let
enable local
enable logout
enable mapfile
enable popd
enable printf
enable pushd
enable pwd
enable read
enable readarray
enable readonly
enable return
enable set
enable shift
enable shopt
enable source
enable suspend
enable test
enable times
enable trap
enable true
enable type
enable typeset
enable ulimit
enable umask
enable unalias
enable unset
enable wait
:\e["

fi

motd+="
${motd_indent}du -h -d2 $PREFIX | du -h -d2 $HOME | du -h /data/data/com.termux/files | sort -h | tail -200
"

echo -e "$motd"
