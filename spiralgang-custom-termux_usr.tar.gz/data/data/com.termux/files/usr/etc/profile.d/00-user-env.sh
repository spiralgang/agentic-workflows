# 00-user-env.sh — consolidated user environment (canonical config)
# Merged 2026-07-12 from: ~/.bashrc, ~/.bash_profile, ~/.bashrootc,
# ~/profile, ~/profile2., not.bashrc. (deduped, secret-stripped, junk dropped.)
# Sourced by /data/data/com.termux/files/usr/etc/profile for login shells,
# and by ~/.bashrc for interactive non-login shells.
# Secrets live in ~/.secrets (mode 600) and are sourced at the end.
#
# Idempotency guard: sourcing this twice (login + interactive) is a no-op.
[ -n "${_USER_ENV_LOADED:-}" ] && return
_USER_ENV_LOADED=1

# --- Prioritize the working Termux PREFIX bins (python3.14, pip, node, etc.)
#     over the supplemental ~/.termux_root rootfs, whose python3.13 stubs are
#     broken. termux_root still provides working curl/git/wget as fallback. ---
export PATH="/data/data/com.termux/files/usr/bin:/data/data/com.termux/files/home/.local/bin:$PATH"

# --- uv (Python toolchain) ---
export PATH="/data/data/com.termux/files/home/.local/bin:$PATH"

# --- Termux scattered-files bridge (symlinked project tooling) ---
alias projects='cd ~/projects'
export PATH="$HOME/projects/termux-dump:$HOME/projects/termux-dump/gradle/wrapper:$PATH"
export PROJECTS_HOME="$HOME/projects"

# --- google-drive-upload ---
if [ -f "${HOME}/.google-drive-upload/bin/gupload" ] && [ -x "${HOME}/.google-drive-upload/bin" ]; then
  PATH="${HOME}/.google-drive-upload/bin:${PATH}"
fi

# --- Android SDK ---
export ANDROID_HOME="$HOME/android-sdk"

# --- termux_root (root helper paths) — placed AFTER /usr/bin so the broken
#     python3.13 stubs don't shadow the working python3.14, while its real
#     curl/git/wget binaries remain available as fallback. ---
export PATH="$HOME/.termux_root/bin:$PATH"
export LD_LIBRARY_PATH="$HOME/.termux_root/usr/lib:$LD_LIBRARY_PATH"
# LD_PRELOAD of libtermux-root.so is intentionally left off: only enable it
# when actually running under the root helper, otherwise it breaks normal shells.
# export LD_PRELOAD="$HOME/.termux_root/usr/lib/libtermux-root.so"

# --- glibc-root binaries (from not.bashrc) ---
export PATH="$PATH:/data/data/com.termux/files/usr/glibc/bin:/data/data/com.termux/files/usr/lib/bin"

# --- Shizuku / rish ---
export RISH_APPLICATION_ID="com.termux"

# --- OpenRouter (model + endpoint only; key sourced from ~/.secrets) ---
export OPENROUTER_AI_MODEL="cognitivecomputations/dolphin-mistral-24b-venice-edition:free"
export OPENROUTER_API_URL="https://openrouter.ai/api/v1/chat/completions"

# --- Google Cloud SDK (if installed) ---
if [ -f "$HOME/google-cloud-sdk/path.bash.inc" ]; then
  . "$HOME/google-cloud-sdk/path.bash.inc"
fi
if [ -f "$HOME/google-cloud-sdk/completion.bash.inc" ]; then
  . "$HOME/google-cloud-sdk/completion.bash.inc"
fi

# --- Secrets (mode 600, not world-readable) ---
if [ -r "$HOME/.secrets" ]; then
  . "$HOME/.secrets"
fi

# --- Interactive shell enhancers (only if installed; guarded) ---
# bash-completion is handled by the system /etc/bash.bashrc above.
if [ -n "${PS1:-}" ] || [[ "${-:-}" == *i* ]]; then
  # ble.sh (Bash Line Editor) — syntax highlight, vim keybindings.
  # Requires a real TTY to attach; skip silently otherwise.
  if [ -t 0 ] && [ -f /data/data/com.termux/files/usr/share/blesh/ble.sh ]; then
    source /data/data/com.termux/files/usr/share/blesh/ble.sh
  fi
  # hstr — history search (Ctrl-R replacement)
  if command -v hstr >/dev/null 2>&1; then
    export HH_CONFIG=hicolor,rawhistory,no-confirm
    bind '"\C-r": "\C-ahstr -- \C-j"'
  fi
  # gbt — git-aware prompt builder (use as PS1 if desired)
  if command -v gbt >/dev/null 2>&1; then
    export GBT_CARS='Status:Time:Battery:User:Host:Ssh:Path:Git:Cpu:Jobs:Docker:Kubectl:Python:Virt:Singularity:Exit:Tag'
  fi
fi

# --- X11 / termux-x11 display default ---
# termux-x11 runs a local X server; default DISPLAY to :0 unless already set.
if command -v termux-x11 >/dev/null 2>&1 && [ -z "${DISPLAY:-}" ]; then
  export DISPLAY=:0
fi

# --- Node / npm / JavaScript toolchain ---
# npm global prefix is /usr, so its bins already live in /usr/bin.
# Ensure the prefix bin dir is explicitly on PATH for portability.
export PATH="/data/data/com.termux/files/usr/bin:$PATH"
export NPM_CONFIG_PREFIX="/data/data/com.termux/files/usr"
export NODE_PATH="/data/data/com.termux/files/usr/lib/node_modules:$NODE_PATH"
# node-gyp (native addon builds) available via npx; alias for convenience
alias node-gyp='npx node-gyp'

# --- Python / pip ---
export PYTHONUSERBASE="/data/data/com.termux/files/home/.local"
export PATH="$PYTHONUSERBASE/bin:$PATH"
export PIP_USER=1

# --- Java / Gradle / Android ---
export JAVA_HOME="/data/data/com.termux/files/usr/lib/jvm/default" 2>/dev/null
[ -d "$JAVA_HOME" ] || export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")"
export GRADLE_USER_HOME="$HOME/.gradle"
export ANDROID_SDK_ROOT="$ANDROID_HOME"

# --- Package managers (apt / dpkg / nala / aptitude / pkg) ---
# All resolve via /usr/bin; mark them discoverable for scripts.
for _pm in apt apt-get dpkg nala aptitude pkg; do
  command -v "$_pm" >/dev/null 2>&1 && export "HAS_$(echo "$_pm" | tr '[:lower:]' '[:upper:]' | tr - _)=1"
done
unset _pm

# --- YAML tooling ---
command -v yq >/dev/null 2>&1 && export HAS_YQ=1

# --- PHP / Composer ---
command -v composer >/dev/null 2>&1 && export HAS_COMPOSER=1
command -v php >/dev/null 2>&1 && export HAS_PHP=1

# --- Web fetch / transfer ---
for _wf in curl wget xdg-open termux-open-url; do
  command -v "$_wf" >/dev/null 2>&1 && export "HAS_$(echo "$_wf" | tr '[:lower:]' '[:upper:]' | tr - _)=1"
done
unset _wf

# --- MCP API access (python http / js fetch / openrouter) ---
# python: requests/httpx; node: global fetch. Keys come from ~/.secrets.
export MCP_HTTP_BASE="${OPENROUTER_API_URL:-https://openrouter.ai/api/v1/chat/completions}"

# --- TeX Live (installed via texlive.profile -> /usr/share/texlive) ---
if [ -d /data/data/com.termux/files/usr/share/texlive/2026/bin ]; then
  export PATH="/data/data/com.termux/files/usr/share/texlive/2026/bin/$(uname -m):$PATH"
fi

