#!/data/data/com.termux/files/usr/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"
source "$SCRIPT_DIR/create_java.sh"

create_web() {
    local app_dir="$1"
    local template_dir="$TEMPLATE_BASE/web"

    if [ ! -d "$template_dir" ]; then
        error "Template directory not found: $template_dir"
    fi

    echo
    spinner "Copying web template..." cp -r "$template_dir" "$app_dir"
    if [ $? -ne 0 ]; then
        error "Copy failed"
    fi

    cd "$app_dir" || error "Cannot enter $app_dir"

    echo
    echo -e "${BOLD}Configuration${RESET}"
    echo -e "${DIM}Please provide the following information:${RESET}"
    echo

    echo -e "${CYAN}App name${RESET} (e.g., MyWebApp)"
    local new_name=$(gum input \
        --placeholder "MyWebApp" \
        --prompt "> " \
        --prompt.foreground 39 \
        --placeholder.foreground 241 \
        --value "$DEFAULT_APP_NAME" \
        --width 60)

    echo
    echo -e "${CYAN}Package name${RESET} (e.g., com.example.webapp)"
    local new_pkg=$(gum input \
        --placeholder "com.example.webapp" \
        --prompt "> " \
        --prompt.foreground 39 \
        --placeholder.foreground 241 \
        --value "$DEFAULT_PACKAGE" \
        --width 60)

    echo
    step "Restructuring project..."

    update_app_name "$(pwd)" "$DEFAULT_APP_NAME" "$new_name"
    update_manifest "$(pwd)" "$DEFAULT_PACKAGE" "$new_pkg"
    update_build_gradle "$(pwd)" "$DEFAULT_PACKAGE" "$new_pkg"
    update_text_files "$(pwd)" "$DEFAULT_PACKAGE" "$new_pkg"
    restructure_dirs "$(pwd)" "$DEFAULT_PACKAGE" "$new_pkg"

    echo
    success "Web project created successfully"
    echo
    echo -e "${BOLD}Next steps:${RESET}"
    echo -e "  ${DIM}1.${RESET} ${WHITE}cd $app_dir${RESET}"
    echo -e "  ${DIM}2.${RESET} ${WHITE}apkgen build debug${RESET}"
    echo
    echo -e "${DIM}Edit START_URL in MainActivity.java to point at your site.${RESET}"
    echo
}
